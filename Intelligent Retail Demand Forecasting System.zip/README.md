
AI Retail Dashboard Starter

Backend:
cd backend
pip install -r requirements.txt
python run.py

Frontend:
Use your React app and replace App.jsx with provided file.
