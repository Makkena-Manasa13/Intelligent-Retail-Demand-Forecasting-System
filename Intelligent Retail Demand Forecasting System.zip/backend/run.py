
from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

products = [
    {"name":"Basmati Rice 5kg","cat":"Groceries","price":12.99,"stock":150,"base":80,
     "img":"https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=200&q=80"}
]

@app.route('/api/products')
def get_products():
    return jsonify(products)

@app.route('/api/dashboard')
def dashboard():
    return jsonify({
        "revenue": 24500,
        "forecast_accuracy": 94,
        "inventory": 1250,
        "alerts": 7
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
