
import React from "react";

export default function App() {
  return (
    <div style={{background:"#0a0e27", minHeight:"100vh", color:"white", padding:"20px"}}>
      <h1>AI Retail Analytics Dashboard</h1>
      <div style={{display:"flex", gap:"20px"}}>
        <div>Total Revenue: $24,500</div>
        <div>Forecast Accuracy: 94%</div>
        <div>Inventory: 1250</div>
      </div>
    </div>
  );
}
